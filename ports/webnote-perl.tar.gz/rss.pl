#!/usr/bin/perl -w
# Generate and RSS2.0 XML file of the workspace.
# NOTE: the geotags feature isnt included in this Perl port
# --------------------------------------------------------------------------------- 
use strict;
use CGI;
use webnote::commondefault;
use webnote::Workspace;
use XML::RSS;

my $q = new CGI;
my $ws = webnote::Workspace->new(
	cgi => $q,
);
$ws->CreateLoad();    

my $dt = str2datetime($ws->{lasttime});

# create an RSS 2.0 file
my $rss = new XML::RSS (version => '2.0');
$rss->channel(title          => "Webnote: " . unquote($ws->{name}),
	link           => "$webnote::commondefault::BASEURL$ws->{name}",
	language       => 'en',
	description    => 'Webnote RSS feed',
	pubDate        => time(),
	lastBuildDate  => "$dt",
	webMaster      => "$webnote::commondefault::HELPEMAIL"
);

# create notes here
my $noteCount = 0;
foreach my $noteRef (@{$ws->{notes}}) {
	my $text = uriUnescape($noteRef->{text});
	$rss->add_item(
		title => "Note $noteCount",
		permaLink  => "$webnote::commondefault::BASEURL$ws->{name}#note$noteCount",
		description => $text,
		);
	$noteCount++;
};


# print the RSS as a string
print "Content-type: text/xml\n\n";
print $rss->as_string;


#reUnicodeChar = re.compile("%u([0-9A-F]{4})")
#reHtmlComments = re.compile("<!--.+-->", re.M | re.S)

sub unquote {
	my $unquotedVal = shift;
	return $unquotedVal;
#  return reUnicodeChar.sub(lambda x: unichr(int(x.group(1), 16)), s)
}

sub uriUnescape {
# Convert all escaped (Hex) values in a passed URI to their character equivalents,
# e.g. %20 is replaced with the binary character for a space
        my $thisString = shift;
        $thisString =~ s/%([a-fA-F0-9]{2})/chr(hex($1))/ge;
        return $thisString;
}


sub str2datetime {
	my $dateString = shift;
    #ret = datetime.datetime.fromtimestamp(time.mktime(time.strptime($dateString, 
    #                                      '%Y-%m-%d %H:%M:%S')))
    #ret = ret - TIMEZONE._utcoffset;
    return $dateString;
}

# NOTE: not using this as XML::RSS seems to escape the content well enough
#def findTags(tag, text):
#  reTag = re.compile(r"""
#      <%(tag)s>          # opening tag
#        (?P<value>.+?)   # everything in between the tags.  Non-greedy.
#      </%(tag)s>         # the closing tag must match the opening tag
#      """ % locals(), re.M | re.S | re.X)
#  matches = reTag.findall(text)
#  if matches:
#    return matches[0]
#  return None

