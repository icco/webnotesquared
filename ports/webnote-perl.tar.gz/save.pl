#!/usr/bin/perl -w
# --------------------------------------------------------------------------------- 
use strict;
use CGI;
use webnote::Workspace;

my $q = new CGI;
my $ws = webnote::Workspace->new(
	cgi => $q,
);

$ws->CreateSave();
my $updateTime = $ws->commit();

if ($updateTime) {
	print "Content-type: text/xml\n\n";
	printf "<return>\n<status value='ok' update='%s'/>\n</return>" , $updateTime;
} else {
	retMsg('error');
}