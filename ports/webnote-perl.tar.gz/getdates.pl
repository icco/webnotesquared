#!/usr/bin/perl -w
# --------------------------------------------------------------------------------- 
use CGI;
use webnote::commondefault;
use webnote::Db;
use webnote::Workspace;
use webnote::message;

my $q = new CGI;
my $ws = webnote::Workspace->new(
	cgi => $q,
);

my $offset = (defined $q->param('offset')) ? $q->param('offset') : '0';
$ws->{name} = (defined $q->param('name')) ? $q->param('name') : '';

print $q->header('text/plain');


unless ($ws->{name}) {
    PlainText("No name entered.");
}

my $sql = "SELECT distinct" .
	" DATE_FORMAT(wn_notes.time, '\%Y-\%m-\%d \%H:\%i:\%s') AS T " .
	" FROM wn_notes INNER JOIN wn_workspaces USING(wsid)" .
	" WHERE wsname='" . $ws->{name} . "' ORDER BY T DESC" .
	" LIMIT " . $offset . ", " . ($webnote::commondefault::NUM_DATES+1);

my @loadTimes;
my $sth = $ws->{dbh}->prepare($sql);
$sth->execute or die "Could not execute SQL: $sql - $sth->errstr";
while (my @row = $sth->fetchrow) {
	push @loadTimes, $row[0];
}

PlainText(join('|',@loadTimes));
