#!/usr/bin/perl -w
# --------------------------------------------------------------------------------- 
use strict;
use CGI;
use webnote::Workspace;

my $q = new CGI;
print $q->header();


my $ws = webnote::Workspace->new(
	cgi => $q,
);

$ws->CreateLoad();
$ws->createHTML();