# Messages returned to the user.
package webnote::message;

BEGIN {
	use Exporter();
	use vars   qw($VERSION @ISA @EXPORT %EXPORT_TAGS);
	@ISA = qw(Exporter);
	@EXPORT  = qw(&Error &PlainText &Redirect);
}


sub Error {
  #"""ex is an exception"""
  my $ex = shift;
  print "Content-type: text/html\n\n";
  print "<html><body><h2>Congratulations!  You found a bug in Webnote!</h2>";
  print "<p>(or perhaps the database is down)</p>";
  print "<p>We'll try to have webnote up and running again as soon as possible</p>";

  if ($webnote::commondefault::SHOWDEBUG) {
   # import cgitb
   # cgitb.handler()
  }
  print '</body></html>';
  webnote::logger::log($ex);
}

sub PlainText {
	my $message = shift;
	#print "\nContent-type: text/plain\n\n";
	print $message;
}

sub Redirect($) {
	my $url = shift || '.';
	print "Location: %s\n\n$url";
}

1;