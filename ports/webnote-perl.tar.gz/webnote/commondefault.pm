package webnote::commondefault;

#Edit this file to set various features of webnote"""


# database information
our $DBHOST = '127.0.0.1';
our $DBUSER = 'username';
our $DBPASS = 'password';
our $DBNAME = 'webnote';

# the root url
our $BASEURL = 'http://yoursite.com/cgi-bin/webnote/';

# your email address
our $HELPEMAIL = 'webmaster@yoursite.com';

# should we log to a file? You need to make sure you have the right file
# permissions to use this.
our $ISLOGGING = 1;
our $LOGFILENAME = '../../logs/webnote-debug.log';

# should we show debug info when the backend has a problem?
our $SHOWDEBUG = 0;
# should we show the js debugging box?
our $SHOWJSDEBUG = 0;

# In the load previous drop down, how many entries should we show?
our $NUM_DATES = 10;

# Timezone uses pytz.  It doesn't really matter unless you want to control
# the timezone saved in MySQL.  See pytz documentation for more details.
#try:
#  import pytz
#  TIMEZONE = pytz.timezone('US/Eastern')
#except ImportError:
our $TIMEZONE = None;

1;