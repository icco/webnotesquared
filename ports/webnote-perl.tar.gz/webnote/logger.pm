package webnote::logger;

BEGIN {
	use Exporter();
	use vars   qw($VERSION @ISA @EXPORT %EXPORT_TAGS);
	@ISA = qw(Exporter);
	@EXPORT  = qw(&log);
}

use Carp;
use webnote::commondefault;


sub log {
	my $msg = shift;
	if ($webnote::commondefault::ISLOGGING) { 
	    warn($msg);
	    #logObj.info('%s %s' % (os.environ.get('HTTP_USER_AGENT', '?'), 
        #                   msg.replace('\n', '\\n')))
	}
}

1;