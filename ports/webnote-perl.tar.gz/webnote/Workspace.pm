package webnote::Workspace;
#"""An abstraction for the workspace."""

#import sys, ost Db
use webnote::Note;
use webnote::commondefault;
use webnote::logger;
use webnote::Db;
use XML::Simple;

sub new {
  #"""An abstraction for the workspace."""
    my $invocant = shift;
    my $class = ref($invocant) || $invocant;
    my $self = {
		name => '',
		notes => [],
		nextNoteNum => 0,
		lasttime => '', # string
	    newNoteText => 'A New Note',
        # --------------------------------------
        @_    # remaining passed arguments
        # -------------------------------------- 
        };
    bless ($self, $class);
    # create a db connection
    $self->{dbh} = webnote::Db::getDBH();
    #self.db = self.dbh.cursor()
	return $self;
};

  
sub createNewWorkspace {
	my $self = shift;
	my $sql = "INSERT INTO wn_workspaces(wsname, nextNoteNum, time)" .
		" VALUES('$self->{name}', '$self->{nextNoteNum}', '$self->{lasttime}')";
    my $sth = $self->{dbh}->prepare($sql);
	$sth->execute or die "Could not execute SQL: $sql - $sth->errstr";

	$sql = "SELECT wsid FROM wn_workspaces WHERE wsname='" . $self->{name} . "'";
    $sth = $self->{dbh}->prepare($sql);
	$sth->execute or die "Could not execute SQL: $sql - $sth->errstr";
	my @row = $sth->fetchrow;
	$self->{wsid} = $row[0];

	#$self->{newID} = $sth->{'mysql_insertid'};	# Last AutoIncrement value
}


sub workspaceExists {
	# DMS - new sub instead of doing the try-catch on createNewWorkspace
	my $self = shift;
	$self->{wsid} = '';
	my $sql = "SELECT wsid FROM wn_workspaces WHERE wsname='" . $self->{name} . "'";
    my $sth = $self->{dbh}->prepare($sql);
	$sth->execute or die "Could not execute SQL: $sql - $sth->errstr";
	return 0 unless ($sth->rows());
	my @row = $sth->fetchrow;
	$self->{wsid} = $row[0];
	return 1;
}


sub commit {
    my $self = shift;
    my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
    $mon++;
    $year = $year + 1900;
    # we save dates in the database localized to the current timezone
    my $nowtime = "$year-$mon-$mday $hour:$min:$sec";
    $self->{lasttime} = $nowtime;
      
    unless ($self->workspaceExists()) {
		$self->createNewWorkspace();
    } else {
		my $sql = "UPDATE wn_workspaces SET nextNoteNum='" . $self->{nextNoteNum} . "'" .
		", time='" . $self->{lasttime} . "' WHERE wsid='" . $self->{wsid} . "'";
	    my $sth = $self->{dbh}->prepare($sql);
		$sth->execute or die "Could not execute SQL: $sql - $sth->errstr";
    }

	my $sqlStart = 'INSERT INTO wn_notes(' . join(',', @DBKEYS) . ',time,wsid) VALUES (';

	foreach my $noteHashRef (@{$self->{notes}}) {
		my %noteNode = %{$noteHashRef};
		my $sql = $sqlStart;
		foreach my $key (@DBKEYS) { $sql .= "'" . $noteNode{$key} . "',"; }
		$sql .= "'$self->{lasttime}','$self->{wsid}')";
	    my $sth = $self->{dbh}->prepare($sql);
		$sth->execute or die "Could not execute SQL: $sql - $sth->errstr";
	}
    return $self->{lasttime};
}

sub createHTML {
    my $self = shift;
    #print $self->{cgi}->header();
    # TODO: replace href in link rel=start
	my $debugOn = 'false';
    if ($webnote::commondefault::SHOWJSDEBUG) {
      $debugOn = 'true';
	}    
    print <<END;
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
    <link rel="start"  type="text/html" href="/tools/webnote/" 
         title="Webnote - an online tool for taking notes" />
    <link rel="SHORTCUT ICON" href="/tools/webnote/webnote_favicon.ico" type="image/x-icon" />
    <script type="text/javascript" src="/tools/webnote/objects.js"></script>
    <script type="text/javascript" src="/tools/webnote/webnote.js"></script>
    <script type="text/javascript">
<!--
function loadinit()
{
  debugOn = "$debugOn";
  workspace.setName(unescape("$self->{name}"));
  workspace.loadedTime = '$self->{lasttime}';
  adminEmail = '$webnote::commondefault::HELPEMAIL';
  baseURI = '$webnote::commondefault::BASEURL';
  numDates = $webnote::commondefault::NUM_DATES;
  init();
END

    # create notes here
    foreach my $noteRef (@{$self->{notes}}) {
    	$self->printJavascript($noteRef);
    }

    # set workspace information
    # this happens after the notes are made to prevent the
    # nextNoteNum from incrementing unnecessarily
    print "  workspace.nextNoteNum = " . $self->{nextNoteNum} . ";";
    # set the status to unchanged
    print "  workspace.changed = false;";

    # create a new note (for bookmarklet hack)
    if ($self->{newNoteText}) {
		my $tempNoteText = $self->{newNoteText};
		$tempNoteText =~ s/'/\\'/;
		printf "workspace.createNote({'text': '%s'});" , $tempNoteText;
	}
    print <<END2;
}
// -->
    </script>
    <link rel="stylesheet" href="/tools/webnote/style.css" type="text/css" />
END2

	my $escapedName = $self->{name};
	$escapedName =~ s/&/&smp;/g;
	$escapedName =~ s/'/&pos;/g;
	$escapedName =~ s/"/&quot;/g;
	print '    <link rel="alternate" type="application/rss+xml" ' .
           'title="' . $escapedName . ' - webnote" href="' . $escapedName . '.xml" />';

#           % (urllib.unquote(self.name).replace('&', '&amp;')
#                                       .replace("'", '&apos;')
#                                       .replace('"', '&quot;'),
#              urllib.quote(urllib.quote(self.name))))

	print <<END3;
	<title>$self->{name}</title>
</head>
<body onload='loadinit();' style='background-color: #f0f0f0;'>
    <div id='toolbar'>
        <div class='controls'>
          <img id="newImg" src='/tools/webnote/images/new.gif' class='controls' onclick="workspace.createNote()" title="new note" alt='new note' />
          <img id="saveImg" src='/tools/webnote/images/save.gif' class='controlsDisabled' onclick="workspace.save()" title="save workspace" alt='save workspace' />
          <img id="reloadImg" src='/tools/webnote/images/reload.gif' class='controls' onclick="workspace.loadlist()" title="load previous version" alt='load previous version' />
          <img id="undoImg" src='/tools/webnote/images/undo.gif' class='controlsDisabled' onclick="workspace.history.undo()" title="nothing to undo" alt='undo icon' />
          <img id="redoImg" src='/tools/webnote/images/redo.gif' class='controlsDisabled' onclick="workspace.history.redo()" title="nothing to redo" alt='redo icon' />
        </div>
        <div id='filters'>
            <input style='width: 135px; padding: 1px 2px 1px 2px;' id='textfilter' title='enter a regular expression to filter by' onchange='workspace.filter(this.value)' onkeydown='if(13==event.keyCode){workspace.filter(this.value);}; event.cancelBubble=true;'/>
            <!-- this button is strictly for looks -->
            <input style='width: 50px;' type='button' value='filter' />
        </div>
        <div id='mini' title='you have no notes'>
        </div>
        <div id='links'>
          <a href="$escapedName.xml" title='rss feed of these notes' ><img style='margin: 6px 2px;border:0;width:19px;height:9px;' src='/tools/webnote/images/minixml.gif' alt='xml' /></a>
        </div>
        <div id='wsname'>
        </div>
    </div>
    <div id='db'></div>
</body>
</html>
END3
}

sub __del__ {
    my $self = shift;
    #if self.db:
     # self.db.close()
}


# global methods for creating Workspaces
sub CreateSave {
    my $self = shift;

    # Get our CGI request information.
    my $method = $ENV{'REQUEST_METHOD'};
    my $type = $ENV{'CONTENT_TYPE'};
    my $length = $ENV{'CONTENT_LENGTH'};

    # Perform some sanity checks.
    http_error(405, "Method Not Allowed") unless $method eq "POST";
    http_error(411, "Length Required") unless $length > 0;

    # Fetch our body. (see http://www.xml.com/pub/a/2005/05/11/ajax-error.html)
	my $body_xml = $self->{cgi}->param('POSTDATA');

    #log(data);
    # there should be something here for catching an incomplete send

	my $xs = new XML::Simple(ForceArray => 1);
    my $rootNode = $xs->XMLin($body_xml);

	$self->{name} = $rootNode->{'name'} || '';
	$self->{nextNoteNum} = $rootNode->{"nextNoteNum"};

	my $notesNode = $rootNode->{'note'};
	my @nlNotes = @{$notesNode};
	for (my $i = 0; $i < (scalar @nlNotes); $i++) {
			my $noteNodeRef = $nlNotes[$i];
			my $noteHashRef = $self->FromXML($noteNodeRef);
			push @{$self->{notes}}, $noteHashRef;
	}
}

# Send an HTTP error and exit.
sub http_error ($$) {
    my ($code, $message) = @_;
    print <<"EOD";
Status: $code $message
Content-type: text/html

<title>$code $message</title>
<h1>$code $message</h1>
<p>Unexpected error processing XML-RPC request.</p>
EOD
    exit 0;
}


sub CreateLoad {
	my $self = shift;

	# get the name, strip invalid quote characters
	my $name = $self->{cgi}->param('name') || '';
	$name =~ s/'//g;
	$self->{name} = $name;
  
	# make sure it's a valid request
	return unless $name;

	# get the workspace data
  	my $sql = "SELECT wsid, nextNoteNum," .
		" DATE_FORMAT(time, '\%Y-\%m-\%d \%H:\%i:\%s')" .
		" FROM wn_workspaces" .
		" WHERE wsname='$name'";
    my $sth = $self->{dbh}->prepare($sql);
	$sth->execute or die "Could not execute SQL: $sql - $sth->errstr";

	if ($sth->rows()) {
		my @row = $sth->fetchrow;
		$self->{wsid} = $row[0];
		$self->{nextNoteNum} = $row[1];
		$self->{lasttime} = $row[2];

		# if there's a form var time use that as user has requested an older set of notes
		if (defined $self->{cgi}->{time} && ($self->{cgi}->{time} ne '')) {
	      $self->{lasttime} = $self->{cgi}->param('time');
		}

	    # load the notes
		my $sqlNotes = 'SELECT ' . join(',', @DBKEYS) . ' FROM wn_notes ' .
			" WHERE wsid='" . $self->{wsid} . "'" .
			" AND wn_notes.time='" . $self->{lasttime} . "'";
		my $sthNotes = $self->{dbh}->prepare($sqlNotes);
		$sthNotes->execute or die "Could not execute SQL: $sqlNotes - $sthNotes->errstr";

		while (my $rowHash = $sthNotes->fetchrow_hashref) {
			my %loadedHash = %{$rowHash};
			my %loadedNote;
			foreach my $key (@DBKEYS) {
				$loadedNote{$key} = $loadedHash{$key};
			}
			push @{$self->{notes}}, \%loadedNote;
		}
	}  
	
	# this is a hack for now
	# TODO: add this to the notes array
	my $newNoteText = $self->{cgi}->param('nn') || '';
	$newNoteText =~ s/\n/\\n/;
	$newNoteText =~ s/\r//;
	$newNoteText =~ s/\l//;
	$self->{newNoteText} = $newNoteText;

	if ($self->{newNoteText}) {
		my $via = $self->{cgi}->param('via') || '';
		$self->{newNoteText} .= "<br />via <a href='$via'>$via</a>";
	}
}  

1;