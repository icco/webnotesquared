# An abstraction representing a Note.
#class Note:
#  """An abstraction representing a Note."""
  
# 'text' must be the last key for printJavascript method
our @JSKEYS = ('id', 'xPos', 'yPos', 'height', 'width',
            'bgcolor', 'zIndex', 'text');
our @DBKEYS = ('noteid', 'xposition', 'yposition', 'height', 'width',
            'bgcolor', 'zindex', 'text');

sub FromTuple {
#    note = Note()
#    d = dict(zip(Note.DBKEYS, args))
#    note.__dict__.update(d)
#    return note
#  FromTuple = staticmethod(FromTuple)
}

sub FromXML {
	my $self = shift;
	my $noteNodeRef = shift;
	my %noteNode = %{$noteNodeRef};
	my %noteHash;
	foreach my $key (@DBKEYS) {
		if ($key ne 'text') {	# skip the text entry in DBKEYS for now
			my $value = $noteNode{$key} || '';
			$value =~ s/'//;
			$noteHash{$key} = $value;
		}
	}
	my $textValue = $noteNode{content};
	$textValue =~ s/'//;
	$noteHash{'text'} = $textValue;
	return \%noteHash;
}
  
sub getValues {
    #"""Return a list of the keys in db order."""
    #return [getattr(self, key) for key in self.DBKEYS]
}

sub __cmp__ {
    #return cmp(self.noteid, rhs.noteid)
}

sub printJavascript {
	my $self = shift;
	my $noteHashRef = shift; # we're passed a ref to hash of note attributes
    print "  workspace.createNote( {";
    for (my $i = 1; $i < (scalar @JSKEYS); $i++) {
	    printf "      '%s': '%s',", $JSKEYS[$i-1], $noteHashRef->{$DBKEYS[$i-1]};
    }
   	printf "      'text': unescape('%s')",  $noteHashRef->{text};
    print "  }, true);"
}