package webnote::Db;

use DBI;
#from etc.common import DBHOST, DBUSER, DBPASS, DBNAME

sub getDBH() {
	my $open_dbh;
	my $dataSource = "DBI:mysql:$webnote::commondefault::DBNAME:$webnote::commondefault::DBHOST";
	$open_dbh=DBI->connect($dataSource, $webnote::commondefault::DBUSER, $webnote::commondefault::DBPASS);
	die ("Could not open DB connection" . DBI->errstr  , "Database Error") unless $open_dbh;
	return $open_dbh;
}

1;