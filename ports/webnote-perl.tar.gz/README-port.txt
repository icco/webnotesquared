
==============================================================
Description: Perl port of 'webnote' back-end CGI scripts.
Author: Dean Stringer (deeknow@pobox.com)
Date: 27/Jan/2006
==============================================================


--------------------------------------------------------------
General Notes
--------------------------------------------------------------

This is a port of Tony Chang's backend Python scripts to Perl. 
The version ported is that which was available from his 
website as of 27/Jan/2006

You will need the main distro for all the support libraries 
and client-side stuff (which is where all the magic happens 
anyway :-)

I have included a copy of webnote.js as it includes a couple
of minor (documented) changes, maybe Tony will fold these back
into his main distro.

Wherever possible methods and scripts retain their original 
logic/flow as found in the Python originals

Have used the same variable, sub, class and filenames and 
conventions

The WS class is also an OO class in the Perl port

SQL statements are mostly identical
	
JS is hardly touched, added a couple of constants for script 
names and images location

No methods have been deleted, tho a couple of minor ones are 
REMd out

Nearly all original inline comments have been left in place

Each of the original CGI Python scripts has the same name 
except with a .pl extension


--------------------------------------------------------------
Installation
--------------------------------------------------------------

NOTE: warnings (-w) and 'use strict' are enabled in the CGI
scripts, if you're in production and not having any problems
you may like to remove them.

Pretty much as per the instructions given with Tony's Python 
distribution

You should really move the 'webnote' module subdirectory to
somewhere in your main site_perl lib path

You may like to setup a couple of ReWrite rules like the 
following to call the CGI's

Rewriterule ^/webnote/(.+).xml$ /usr/local/apache/cgi-bin/webnote/rss.pl?name=$1 [T=application/x-httpd-cgi,L]
Rewriterule ^/webnote/(.+) /usr/local/apache/cgi-bin/webnote/load.pl?name=$1 [T=application/x-httpd-cgi,L]


--------------------------------------------------------------
Library Changes
--------------------------------------------------------------

Each of the original Python libraries is present with the same 
name but a .pm extension

Have used the XML:RSS module (avail from CPAN) for RSS 2.0 
generation

Have used the XML::Simple module (avail from CPAN) for parsing 
of AJAX submitted XML from the browser

[Functionality Not Ported]

as logging can be a sensitive issue :-) in some environments 
the log() method is making a call to the carp function

Geotagging has not been implemented in the RSS script


--------------------------------------------------------------
Issues
--------------------------------------------------------------

Had trouble w CGI.pm and extracting the browser posted XML 
data to save.pl (needed to use the POSTDATA var not POST) 
which wasn't documented in my ver of CGI.pm
	
Am having a prob with the filter element in the page, doesnt 
seem to be working, havent really looked into it yet
	
Minor tweak to the DATE-FORMAT strings in the SQL statements 
to change the '%' Python escape chars to '\'
