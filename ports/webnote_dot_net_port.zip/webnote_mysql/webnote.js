/**
 * @fileoverview The Webnote specific classes.<br /><br />
 *
 * The two main classes are {@link workspace} and {@link Note}.
 *
 * {@link workspace} represents the workspace as a whole.  It contains
 * refernces to all the notes and methods for operations such as saving
 * the notes or undo-ing/redo-ing an action.
 */

// global variables
// user options
var debugOn = 1;
var notePadding = 5;
var noteBorder = 2;
var noteBorderColor = '#336699';
var miniWidth = 51;
var exposeSize = "70";
var adminEmail = 'eric at gmail dot com';
var baseURI = 'http://';
var colorMap = {
  '#ffff30': 'yellow',
  '#8facff': 'blue',
  '#7fff70': 'green',
  '#ff6060': 'red',
  '#ffb440': 'orange',
  '#ff6bef': 'purple',
  '#ffffff': 'white',
  '#b0b0b0': 'grey'
};
var bgColors = new Array();
for (var c in colorMap)
{
  bgColors.push(c);
}

// include other file(s)
document.write('<script type="text/javascript" src="objects.js"></script>');
document.write('<script type="text/javascript" src="workspace.js"></script>');
document.write('<script type="text/javascript" src="note.js"></script>');

// other global variables, you shouldn't change these
var isIE = (document.all) ? true : false;
var isSaf = (navigator.userAgent.toLowerCase().indexOf('safari') != -1);

//
// Mouse objects
//

/**
 * @class A class that tracks the mouse position and handles mouse events.
 * @constructor
 */
var Mouse =
{
  /**
   * When resizing a note, this determines which edges need to be moved and
   * which edges remain fixed.  It is a dictionary from string -> boolean
   * where the string is either 'top, 'right', 'bottom' or 'left' and true
   * means the edge is moving.
   * @see Note#mouseMove
   * @type dictionary
   */
  notePosRel : {},
  /**
   * The current location of the mouse.  We initialize it to a dummy value
   * because object.js probably hasn't loaded yet (and Point is undefined).
   * It actually gets set in {@link GLOBALS#init}
   * @type Point
   */
  curPos : 0,

  /**
   * Update the mouse position and resize/move notes if necessary.
   * @param {int} x x position
   * @param {int} y y position
   */
  update : function(x, y)
  {
    this.curPos.x = x;
    this.curPos.y = y;

    // if something is selected
    if (this.selObj)
      this.selObj.update(this);
  },
  /**
   * Select a note either for dragging or for resizing.
   * @param {Note} note the selected note
   * @param {event} ev the javascript event object
   */
  select : function(note, ev)
  {
    if (this.selObj) // something already selected
      return;

    if (get(note.id).style.cursor != "move")
      this.selObj = new SelectedObjectResize(note, this.notePosRel);
    else
    {
      if (ev.altKey)
      {
        this.selObj = new SelectedObjectResize(note, 
              {'top': false, 'bottom':true, 'left':false, 'right':true});
      }
      else if (ev.ctrlKey)
        this.selObj = new SelectedObjectDrag(note, true)
      else
        this.selObj = new SelectedObjectDrag(note, false);
    }
    this.downPos = this.curPos.copy();
    
    // move the selected item to the top
    workspace.reZOrder(note.id);
  },
  /**
   * Release selected notes.
   */
  deselect : function()
  {
    if (this.selObj)
    {
      this.selObj.deselect();
      delete this.selObj;
    }
  }
};


/**
 * Create a new Dragging object.
 * @class A class that contains information about note(s) that is being
 * dragged.
 * @see Mouse#select
 * @param {Note} note a reference to the note being dragged
 * @param {boolean} isGroup are we dragging all notes of the same color?
 * @constructor
 */
function SelectedObjectDrag(note, isGroup)
{
  /**
   * The note(s) being dragged.
   * @type Array
   */
  this.notes = new Array();
  
  // if ctrl is down, move all the notes of the same color
  if (isGroup)
  {
    for (var n in workspace.notes)
    {
      if (workspace.notes[n].bgColor.toString() == note.bgColor.toString())
      {
        this.notes.push( { 'id' : workspace.notes[n].id, 
              'pos' : workspace.notes[n].getPosition() } );
      }
    }
  }
  else // single note move
    this.notes.push( { 'id' : note.id, 'pos' : note.getPosition() } );
  
  // set the border color of the notes that are being moved
  var elt;
  for (n in this.notes)
  {
    elt = get(this.notes[n].id);
    elt.style.border =  noteBorder + 'px #980000 solid';
  }
}
/**
 * Update the position of note(s) when the user moves the mouse.
 * @param {Mouse} md a reference to the parent mouse object
 */
SelectedObjectDrag.prototype.update = function(md)
{
  var offset = md.curPos.sub(md.downPos);
  var elt;
  for (n in this.notes)
  {
    elt = get(this.notes[n].id);
    var newPos = this.notes[n].pos.add(offset);
    elt.style.left = newPos.x + 'px';
    elt.style.top = newPos.y + 'px';
  }
};
/**
 * When we drop a note, we need to reset the colors of borders and add
 * information to the undo stack.
 */
SelectedObjectDrag.prototype.deselect = function()
{
  // check to see if we moved the object(s). if we did, add 
  // information to the undo stack.
  var md = workspace.mouse;
  var offset = md.curPos.sub(md.downPos);
  if (!offset.equals(new Point(0, 0)))
  {
    var f = {
      title : 'move note(s)',
      notes : this.notes,
      off : offset,
      undo : function()
      {
        var elt;
        for (n in this.notes)
        {
          elt = get(this.notes[n].id);
          pos = this.notes[n].pos;
          elt.style.left = pos.x + 'px';
          elt.style.top = pos.y + 'px';
        }
      },
      redo : function()
      {
        var elt;
        for (n in this.notes)
        {
          elt = get(this.notes[n].id);
          pos = this.notes[n].pos.add(this.off);
          elt.style.left = pos.x + 'px';
          elt.style.top = pos.y + 'px';
        }
      }
    };
    
    workspace.history.add(f);
  }
  // reset the border color to black
  var elt;
  for (var n in this.notes)
  {
    elt = get(this.notes[n].id);
    elt.style.border =  noteBorder + 'px ' + noteBorderColor + ' solid';
  }
};


// inheritance might be useful here
/**
 * Create a new Resizing object.
 * @class A class that contains information about a note being resized.
 * @see Mouse#select
 * @param {Note} note a reference to the note being dragged
 * @param {dictionary} pnotePosRel which edges are being resized? It is 
 * a dictionary from string -> boolean where the string is either
 * 'top, 'right', 'bottom' or 'left' and true means the edge is moving.
 * @constructor
 */
function SelectedObjectResize(note, pnotePosRel)
{
  /**
   * The note being resized
   * @type Note
   */
  this.note = note;
  /**
   * The original size of the note
   * @type Point
   */
  this.size = note.getSize();
  /**
   * The original position of the note
   * @type Point
   */
  this.pos = note.getPosition();
  /**
   * The edges being moved.
   * @type dictionary
   */
  this.edges = pnotePosRel;
}
/**
 * Update the size of the note when the user moves the mouse.
 * @param {Mouse} md a reference to the parent Mouse object
 */
SelectedObjectResize.prototype.update = function(md)
{
  var elt = get(this.note.id);

  // this depends on which edge they grabbed
  var minSize = 10;
  var offset = md.curPos.sub(md.downPos);
  if (this.edges['top'])
  {
    if (this.size.y - offset.y > minSize)
    {
      elt.style.top = (this.pos.y + offset.y) + 'px';
      elt.style.height = (this.size.y - offset.y) + 'px';
    }
  }
  else if (this.edges['bottom'])
    elt.style.height = Math.max(this.size.y + offset.y, minSize) + 'px';
  
  if (this.edges['left'])
  {
    if (this.size.x - offset.x > minSize)
    {
      elt.style.left = (this.pos.x + offset.x) + 'px';
      elt.style.width = (this.size.x - offset.x) + 'px';
    }
  }
  else if (this.edges['right'])
    elt.style.width = Math.max(this.size.x + offset.x, minSize) + 'px';
  
  if (this.note.parent.edit == this.note)
  {
    var edit = get(this.note.id + 'text');
    var pSize = this.note.getCorrectedSize();
    pSize.x -= 2*(noteBorder+notePadding+1);
    pSize.y -= 2*(noteBorder+notePadding+1) + 16;
    edit.style.height = pSize.y + 'px';
    edit.style.width = pSize.x + 'px';
  }
  
  this.note.updateSize();
};
/**
 * Add information to the undo stack when the user stops resizing.
 */
SelectedObjectResize.prototype.deselect = function() 
{
  // add information to the undo stack if the item was resized
  var curSize = this.note.getSize();
  
  if (!this.size.equals(curSize))
  {
    var f = {
      title : 'resize note',
      usize : this.size,
      upos : this.pos,
      rsize : curSize,
      rpos : this.note.getPosition(),
      id : this.note.id,
      undo : function()
      {
        this.set(this.usize, this.upos);
      },
      redo : function()
      {
        this.set(this.rsize, this.rpos);
      },
      set : function(size, pos)
      {
        var elt = get(this.id);
        elt.style.top = pos.y + 'px';
        elt.style.left = pos.x + 'px';
        elt.style.height = size.y + 'px';
        elt.style.width = size.x + 'px';
        workspace.notes[this.id].updateSize();
      }
    };
    workspace.history.add(f);
  }
};


/**
 * @class A class that maintains the undo/redo stacks.
 */
// notice that class is using var to implement singleton pattern
var History =					
{
  /**
   * The number of items to keep in the undo stack.
   * @type int
   */
  maxSize : 40,
  /**
   * @type Array
   */
  undoStack : new Array(), // each item in the array is an object
  /**
   * @type Array
   */
  redoStack : new Array(), // with methods called undo and redo
  
  /**
   * Add an event to the undo stack.  This clears the redo stack.
   * @param {function} funcPtr a closure that when called will
   * undo the last action
   */
  add : function(funcPtr)
  {
    this.redoStack = new Array();
    this.undoStack.push(funcPtr);
    if (this.undoStack.length > this.maxSize)
      this.undoStack.shift();
    this.updateTitles();
  },
  /**
   * Undo the last action and move an item from the undo stack to the 
   * redo stack.
   */
  undo : function()
  {
    if (this.undoStack.length > 0)
    {
      f = this.undoStack.pop();
      this.redoStack.push(f);
      f.undo();
      this.updateTitles();
    }
  },
  /**
   * Redo the last undo action.  Moves the action back to the undo stack.
   */
  redo : function()
  {
    if (this.redoStack.length > 0)
    {
      f = this.redoStack.pop();
      this.undoStack.push(f);
      f.redo();
      this.updateTitles();
    }
  },
  /**
   * Update the tool tips on the undo and redo icons.
   */
  updateTitles : function()
  {
    var elt = get('undoImg');
    if (0 == this.undoStack.length)
    {
      elt.title = 'nothing to undo';
      elt.className = 'controlsDisabled';
      elt = get('saveImg');
      elt.className = 'controlsDisabled';
    }
    else
    {
      elt.title = this.undoStack[this.undoStack.length-1].title 
          + ' (' + this.undoStack.length + ' action(s))';
      elt.className = 'controls';
      elt = get('saveImg');
      elt.className = 'controls';
    }
    elt = get('redoImg');
    if (0 == this.redoStack.length)
    {
      elt.title = 'nothing to redo';
      elt.className = 'controlsDisabled';
    }
    else
    {
      elt.title = this.redoStack[this.redoStack.length-1].title 
          + ' (' + this.redoStack.length + ' action(s))';
      elt.className = 'controls';
    }
  }
};

// 
/**
 * @class A generator class that returns the position of the next new note.
 */
var NotePos =
{
  /**
   * @type int
   */
  x : 170,
  /**
   * @type int
   */
  y : 40,
  /**
   * Compute the position of a new note given the size of the note.
   * @param {int} w the width of the new note
   * @param {int} h the height of the new note
   * @type Point
   */
  nextPos : function(w, h)
  {
    var ret = new Point(this.x, this.y);
    
    this.x += 20;
    this.y += 20;
    var s = getPageSize();
    if (this.x + w > s.x || this.y + h > s.y)
    {
      this.x = 40;
      this.y = 40;
    }
    
    return ret;
  }
};




/////////////////////////////////////////
///////// GLOBAL METHOD \\\\\\\\\\\\\\\\\
/////////////////////////////////////////

/**
 * Write a message to the debug textarea.
 * @param {string} msg the message to display
 */
function db(msg)
{
  if (debugOn)
    get('debug').value += '\n' + msg;
}

/**
 * Initialize the workspace.
 */
function init()
{
  if (debugOn)
  {
    get('db').innerHTML = "<form name='debugForm'>" +
        "<textarea style='position:absolute;right:10px;' id='debug' cols='50' rows='10'></textarea>" +
        "<input type='button' onclick='document.debugForm.debug.value=\"\";' value='clear' />" +
        "</form>";
    get('debug').value = '';
  }
  
  // a hack for safari compatability
  if (isSaf)
  {
    escape = myescape;
    //unescape = myunescape;
  }
  
  
  // absolute mouse positions; modified from:
  // http://www.web-wise-wizard.com/javascript-tutorials/javascript-mouse-event-handlers.html
  workspace.mouse.curPos = new Point();
  document.onmousemove = function(e)
    {
      var x, y;
      if (isIE)
      {
        x = window.event.x+document.body.scrollLeft;
        y = window.event.y+document.body.scrollTop;
        //mMax = new Point(document.body.clientWidth+document.body.scrollLeft,
        //    document.body.clientHeight+document.body.scrollTop);
      }
      else
      {
        x = e.pageX;
        y = e.pageY;
        //mMax = new Point(window.innerWidth+window.pageXOffset,
        //    window.innerHeight+window.pageYOffset);
      }
      workspace.mouse.update(x, y);
    };

  document.onkeydown = function(ev)
    {
      // the keydown event only seems to be a document event so we
      // can't put the event on the div layer.  Instead, events
      // need to be passed to the note that is being hovered over.
      if (isIE)
        ev = window.event;
      if (workspace.mouse.noteOver)
        workspace.mouse.noteOver.keyDown(ev);

      if (workspace.shortcuts && !workspace.edit)
      {
        var key = String.fromCharCode(ev.keyCode);
        if ('N' == key)
          workspace.selectNote(1);
        else if ('P' == key)
          workspace.selectNote(-1);
        else if ('B' == key)
        {
          workspace.createNote({
          'text':"This is a bookmarklet for quickly adding new notes.  Right click on the link and add it as a bookmark.  You can now quickly create a note by selecting text on any webpage and then clicking your bookmark.\n"
            + "<a href=\"javascript:var d=document;var e=encodeURIComponent;if(d.getSelection)txt=d.getSelection();if(d.selection)txt=d.selection.createRange().text;location.href='" + baseURI + "load.py?name="
            + escape(escape(escape(workspace.name))) + "&via='+e(location.href)+'&nn='+e(txt);\">new note</a>"});
        }
        else if ('E' == key)
        {
          workspace.expose();
          // swap the functionality with the undo effect
          var tmp = workspace.expose;
          workspace.expose = workspace._expose;
          workspace._expose = tmp;
        }
      }
    };
  
  /**
   * When the user navigates away, if there are changes, give the user a
   * chance to cancel.
   */
  window.onbeforeunload = function()
    {
      if (workspace.changed && workspace.name != "Sample Workspace")
      {
        return "Your notes have not been saved and you may lose some information.";
      }
    };

  /**
   * If the user clicks on the background, turn of note editing.
   */
  document.onmousedown = function(ev)
    {
      workspace.editOff();
    };
  /**
   * @see workspace#mouseUp
   */
  document.onmouseup = function(ev)
    {
      workspace.mouseUp();
    };
  
  /**
   * Clean up memory leaked by bug in IE.
   * from youngpup.net
   */
  window.onunload = function()
    {
      if (isIE)
      {
        var cearElementProps = [
            'onmouseover',
            'onmouseout',
            'onmousedown',
            'onmouseup',
            'onmousemove',
            'ondblclick',
            'onclick',
            'onselectstart',
            'ondragstart',
            'onkeydown'
        ];
        var el;
        for(var d = document.all.length;d--;){
            el = document.all[d];
            for(var c = cearElementProps.length;c--;){
                el[cearElementProps[c]] = null;
            }
        }
      }
    };
  
  // periodically check for updates (every 10 minutes)
  window.setTimeout('workspace.checkUpdated()', 1000*60*10);
}

/**
 * Get the size of the browser.
 * @type Point
 */
function getPageSize()
{
  var ret;
  if (isIE)
  {
    ret = new Point(document.documentElement.clientWidth, 
            document.documentElement.clientHeight);
  }
  else
    ret = new Point(window.innerWidth, window.innerHeight);
  return ret;
}

/**
 * Get a reference to an html object given the id.
 * @param {string} id id of the object
 * @type {HtmlElement}
 */
function get(id) { return document.getElementById(id); }
