using System;
// Added
using System.Web.UI;            // Control
using System.IO;                // For file read/write

/// <summary>
/// This method logs the input variable 'msg' to a file log.txt
/// </summary>
namespace Logging
{
    public class Log : Control
    {
        public void log(string msg)
        {
            // Open a file for reading and writing.
            // Second parameter, "true", tells the StreamWriter to append the text if file exist or create file if it doesnt.
            using (StreamWriter sw = new StreamWriter(Server.MapPath("logs\\log.txt"), true))
            {
                // Add some text to the file.
                sw.WriteLine(DateTime.Now + "   " + msg);
            }
        }
    }
}