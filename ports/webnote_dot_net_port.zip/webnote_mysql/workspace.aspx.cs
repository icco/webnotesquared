using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
// Added
using System.Data.Odbc;         // For database connection to MySQL
using System.IO;                // For file read/write
using System.Text;              // For 'StringBuilder' class

public partial class workspace_aspx
{
    // Fields
    string workspaceName;       // stores the name of the current workspace
    string username;            // stores the current user name

    void Page_Load(Object sender, EventArgs e)
    {        
        int[] notes;              // stores all the notes in XML format
        string lasttime = "";          // lasttime this page was saved??
        int wsid;                 // id of current workspace
        string newNoteText = "";       //
        int nextNoteNum = 0;      // the id number for when we add another note to this workspace, default is 0 (for new workspaces)
        int debug = 0;            // toggle workspace debug

        workspaceName = Request.QueryString["name"];
        username = Request.QueryString["user"];

        //////// START JAVASCRIPT INITIALIZATION \\\\\\\\
        Response.Write(
                "<script type=\"text/javascript\">\n<!--\n" +
                "function loadinit()\n" +
                "{\n" +
                "   debugOn = " + debug + "; // turns on debug mode\n" +
                "   workspace.setName(\"" + workspaceName + "\");\n" +
                "   workspace.loadedTime = '" + lasttime + "';\n" +
                "   workspace.username = '" + username + "';\n" +
                "   init();\n\n"
                );

                        // DESIRED OUTPUT
                        /*
                            <script type="text/javascript">

                            function loadinit()
                            {
                            debugOn = 0; // turns on debug mode
                            workspace.setName("blah");
                            workspace.loadedTime = 'lasttime';
                            init();
                        
                        */

        //////// OUTPUT EACH NOTE FROM DATABASE \\\\\\\\\\\

        // If workspace already exist, print out notes
        if (existsInDB(workspaceName, username))
        {
            // Set variables wsid, nextNoteNum, lasttime
            wsid = getWsid(workspaceName, username);
            nextNoteNum = getNextNoteNum(workspaceName, username);
            lasttime = getLastTime(workspaceName, username);

            OdbcConnection conn = new OdbcConnection(Application["connStr"].ToString());

            try
            {
                conn.Open();
                                
                // Retrieve all the notes from current workspace 
                string query = "SELECT noteid, text, bgcolor, xposition, yposition, height, width, zindex " +
                         "FROM wn_notes, wn_userworkspaces " +
                         "WHERE wn_notes.wsid='" + wsid + "' " +
                         "AND wn_userworkspaces.wsid ='" + wsid + "' " +
                         "AND wn_notes.time='" + lasttime + "' " +
                         "AND wn_userworkspaces.username='" + username + "' " +
                         "ORDER BY nid;";


                log("WORKSPACE.ASPX PAGELOAD:    " + query);

                OdbcCommand cmd = new OdbcCommand(query, conn);
                OdbcDataReader reader = cmd.ExecuteReader();

                // Print out the javascript to create each note
                while (reader.Read())
                    //Response.Write(string.Concat(reader["noteid"], "", reader["text"], "", reader["bgcolor"]));
                    Response.Write(
                        "   workspace.createNote( {\n" +
                            "      'id' : '" + reader["noteid"] + "',\n" +
                            "      'xPos' : '" + reader["xposition"] + "',\n" +
                            "      'yPos' : '" + reader["yposition"] + "',\n" +
                            "      'height' : '" + reader["height"] + "',\n" +
                            "      'width' : '" + reader["width"] + "',\n" +
                            "      'bgcolor' : '" + reader["bgcolor"] + "',\n" +
                            "      'zIndex' : '" + reader["zindex"] + "',\n" +
                            "      'text' : unescape('" + reader["text"] + "')\n" +
                            "   } );\n\n"
                    );
            }
            catch (OdbcException ex)
            {
                Response.Write(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }
        else
        {
            // Create the database for this workspace if it does not exist
            createDatabase(workspaceName, username, nextNoteNum);
        }

        // Javascript code to output each note
        /*
        "workspace.createNote( {" +
            "'id' : 'note2'," +
            "'xPos' : '3'," +
            "'yPos' : '28'," +
            "'height' : '141'," +
            "'width' : '465'," +
            "'bgcolor' : '#ff6060'," +
            "'zIndex' : '1'," +
            "'text' : unescape('%3Cb%3E690%3C/b%3E%20%0ANotes%0Ahttp%3A//www.cs.rochester.edu/%7Egildea/csc282/%0A%0A-%20how%20to%20graph%20functions%20n/2%20%20n%5E2%2C%20etc%0A')" +
        "} );\n" +
        */

        ////////// FINISH OUTPUTTING NOTES \\\\\\\\\\\\
        Response.Write(
                "   workspace.nextNoteNum = " + nextNoteNum + ";\n" +
                "   workspace.changed = false;\n" +         // set the status to unchanged
                "\n}\n" +
                "-->\n<" + "/script>\n"
        );

    }

    // Retrive the wsid of the current workspace and user
    public int getWsid(string workspaceName, string username)
    {
        int wsid = -1;

        OdbcConnection conn = new OdbcConnection(Application["connStr"].ToString());

        try
        {
            conn.Open();

            // Retrieve the wsid of the current workspace
            string query = "SELECT wn_workspaces.wsid FROM wn_workspaces, wn_userworkspaces " +
                            "WHERE wn_workspaces.wsname='" + workspaceName + "' " +
                            "AND wn_userworkspaces.username='" + username + "' " +
                            "AND wn_userworkspaces.wsid=wn_workspaces.wsid;";

            log("WORKSPACE.ASPX GETWSID:    " + query);

            OdbcCommand cmd = new OdbcCommand(query, conn);
            OdbcDataReader reader = cmd.ExecuteReader();

            reader.Read();

            wsid = Convert.ToInt32(reader[0].ToString());
        }
        catch (OdbcException ex)
        {
            log(ex.Message);
        }
        finally
        {
            conn.Close();
        }

        return wsid;
    }

    // Retrive the nextNoteNum of the current workspace and user
    public int getNextNoteNum(string workspaceName, string username)
    {
        int nextNoteNum = -1;

        OdbcConnection conn = new OdbcConnection(Application["connStr"].ToString());

        try
        {
            conn.Open();

            // Retrieve the nextNoteNum of the current workspace
            string query = "SELECT wn_workspaces.nextNoteNum FROM wn_workspaces, wn_userworkspaces " +
                            "WHERE wn_workspaces.wsname='" + workspaceName + "' " +
                            "AND wn_userworkspaces.username='" + username + "' " +
                            "AND wn_userworkspaces.wsid=wn_workspaces.wsid;";

            log("WORKSPACE.ASPX NEXTNOTENUM:    " + query);

            OdbcCommand cmd = new OdbcCommand(query, conn);
            OdbcDataReader reader = cmd.ExecuteReader();

            reader.Read();

            nextNoteNum = Convert.ToInt32(reader[0].ToString());
        }
        catch (OdbcException ex)
        {
            log(ex.Message);
        }
        finally
        {
            conn.Close();
        }

        return nextNoteNum;
    }

    // Retrive the lasttime of the current workspace and user
    public string getLastTime(string workspaceName, string username)
    {
        string lasttime = "";

        OdbcConnection conn = new OdbcConnection(Application["connStr"].ToString());

        try
        {
            conn.Open();

            // Retrieve the time of the current workspace
            string query = "SELECT DATE_FORMAT(wn_workspaces.time, '%Y-%m-%d %H:%i:%s') FROM wn_workspaces, wn_userworkspaces " +
                            "WHERE wn_workspaces.wsname='" + workspaceName + "' " +
                            "AND wn_userworkspaces.username='" + username + "' " +
                            "AND wn_userworkspaces.wsid = wn_workspaces.wsid;";

            log("WORKSPACE.ASPX GETLASTTIME:    " + query);

            OdbcCommand cmd = new OdbcCommand(query, conn);
            OdbcDataReader reader = cmd.ExecuteReader();

            reader.Read();

            lasttime = reader[0].ToString();
        }
        catch (OdbcException ex)
        {
            log(ex.Message);
        }
        finally
        {
            conn.Close();
        }

        return lasttime;
    }

    //////////////////////////////////////////////////////////
    // Check if workspace already exists in database
    // Returns true if exist, false if not
    public Boolean existsInDB(string workspaceName, string username)
    {
        OdbcConnection conn = new OdbcConnection(Application["connStr"].ToString());

        try
        {
            conn.Open();

            string query = "SELECT count(wn_workspaces.wsname) FROM wn_workspaces, wn_userworkspaces " +
                                "WHERE wn_workspaces.wsname='" + workspaceName + "' " +
                                "AND wn_userworkspaces.username='" + username + "' " +
                                "AND wn_userworkspaces.wsid=wn_workspaces.wsid;";

            log("WORKSPACE.ASXP EXISTSINDB:    " + query);

            OdbcCommand cmd = new OdbcCommand(query, conn);
            OdbcDataReader reader = cmd.ExecuteReader();
            reader.Read();
            
            if (reader[0].ToString() == "1")
                return true;
        }
        catch (OdbcException ex)
        {
            log(ex.Message);
        }
        finally
        {
            conn.Close();
        }

        return false;
    }

    ///////////////////////////////////////////////////////////////////
    // Verifies if workspace exist in database, if not creates it
    // If exist, update the timestamp for the workspace
    // Requires:    existsInDB(), nextNoteNum, workspaceName
    public void createDatabase(string workspaceName, string username, int nextNoteNum)
    {
        OdbcConnection conn = new OdbcConnection(Application["connStr"].ToString());

        try
        {
            conn.Open();
            string query;

            // If workspace exist, update timestamp, else create workspace
            if (existsInDB(workspaceName, username))
            {
                query = "UPDATE wn_workspaces SET nextNoteNum='" + nextNoteNum + "', time=now() " +
                                    "WHERE wsname='" + workspaceName + "';";
            }
            else
            {
                query = "INSERT INTO wn_workspaces(wsname, nextNoteNum, time) " +
                                    "VALUES('" + workspaceName + "', '" + nextNoteNum + "', now());";
            }

            log("WORKSPACE.ASPX CREATEDATABASE:    " + query);

            OdbcCommand cmd = new OdbcCommand(query, conn);
            cmd.ExecuteNonQuery();

        }
        catch (OdbcException ex)
        {
            log(ex.Message);
        }
        finally
        {
            conn.Close();
        }
    }

    ////////////////////////////////////////////////////////////////
    ///// LOGGING!!
    // This method logs the input variable 'msg' to a file log.txt
    public void log(string msg)
    {   
        // Open a file for reading and writing.
        // Second parameter, "true", tells the StreamWriter to append the text if file exist or create file if it doesnt.
        using (StreamWriter sw = new StreamWriter(Server.MapPath("logs\\log.txt"), true))
        {
            // Add some text to the file.
            sw.WriteLine(DateTime.Now + "   " + msg);           
        }
    }

    /// <summary>
    /// Create a new workspace for this user
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    void btnCreate_Click(object sender, EventArgs e)
    {
        Response.Redirect("workspace.aspx?name=" + txtNewWorkspace.Text + "&user=" + username);
    }

    /// <summary>
    /// Sign out current user and redirect to login screen
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    void btnSignOut_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    ////////////////////////////////////////////////////////////
    // Retrieves all the workspaces of the current user and displayed in the nav
    // This method is called in the asp code
    public string retrieveWorkspaces(string username)
    {
        StringBuilder html = new StringBuilder();

        OdbcConnection conn = new OdbcConnection(Application["connStr"].ToString());

        try
        {
            conn.Open();

            string query = "SELECT wn_workspaces.wsname FROM wn_workspaces, wn_userworkspaces " +
                                "WHERE wn_userworkspaces.username='" + username + "' " +
                                "AND wn_userworkspaces.wsid = wn_workspaces.wsid;";

            log("WORKSPACE.ASPX RETRIEVEWORKSPACES:    " + query);

            OdbcCommand cmd = new OdbcCommand(query, conn);
            OdbcDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                html.Append("<TR><TD><A href='workspace.aspx?user=" + username + "&name=");
                html.Append(reader["wsname"] + "'>" + reader["wsname"].ToString().ToUpper() + "</A></TD></TR>");
            }

            //log("html:    " + html.ToString());

        }
        catch (OdbcException ex)
        {
            log(ex.Message);
        }
        finally
        {
            conn.Close();
        }

        return html.ToString();
    }
}