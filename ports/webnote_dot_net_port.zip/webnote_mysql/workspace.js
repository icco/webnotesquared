/**
 * @class A class that represents the workspace.  This includes maintaining
 * information about the notes and undo/redo information.
 */
// notice that class is using var to implement singleton pattern
var workspace = 
{
  /**
   * A dictionary of all the notes.
   * @type dictionary
   */
  notes : {},
  /**
   * When creating new notes, we sometimes need to assign a random name to
   * it.  The first random note is note0, the second is note1, etc.
   * @type int
   */
  nextNoteNum : 0,
  /**
   * Number of notes on the workspace.  We keep this as a separate variable
   * since there's no way to determine the size of a dictionary.
   * @type int
   */
  numNotes : 0,
  /**
   * The last time that we loaded this workspace (used to check for update
   * collision).
   * @type int
   */
  loadedTime : 0,
  /**
   * Have we changed the workspace?
   * @type boolean
   */
  changed : false,
  /**
   * The note we are editing.
   * @type Note
   */
  edit : '',
  /**
   * The name of the workspace.
   * @type string
   */
  name : 'Untitled',
  
  /**
   * @type History
   */
  history : History,
  /**
   * @type NotePos
   */
  notePos : NotePos,
  /**
   * @type Mouse
   */
  mouse : Mouse,
  /**
   * Should keyboard shortcuts work?
   * @type boolean
   */
  shortcuts : false,
  /**
   * User that owns this workspace
   * @type string
   */
  username : '',
 

  /**
   * Create a new note. Any of the parameter values may be left blank
   * and default values will be used.
   * @param {dictionary} note a dictionary with any of the following keys:
   * note['id'] = the name of the note<br />
   * note['xPos'] = the x position of the note<br />
   * note['yPos'] = the y position of the note<br />
   * note['height'] = the height of the note<br />
   * note['width'] = the width of the note<br />
   * note['bgcolor'] = the background color of the note (hex)
   * note['zIndex'] = the stacking position of the note
   * note['text'] = the text value of the note
   */
  createNote : function(note)
  {
    if (!note)
      note = {};
    if (!('id' in note))
    {
      note.id = "note" + this.nextNoteNum;
      
      // a new note is being made, save information to the undo stack
      var self = this;
      f = {
        title : 'create note',
        nnn : this.nextNoteNum,
        id : note.id,
        pos : new Point(this.notePos.x, this.notePos.y),
        undo : function()
        {
          self.notes[this.id].destroy(); // don't add to history
          self.nextNoteNum = this.nnn;
        },
        redo : function()
        {
          self.createNote({'id': this.id, 'xPos' : this.pos.x, 
              'yPos' : this.pos.y});
          self.nextNoteNum++;
        }
      };
      this.history.add(f);
      
      this.nextNoteNum++;
    }

    // don't create a layer if it already exists, just move it to the top
    if (get(note.id))
    {
      this.reZOrder(note.id);
      return;
    }
    
    if (!('height' in note)) note.height = 150;
    if (!('width' in note)) note.width = 250;

    var pos;
    if (!('xPos' in note) || !('yPos' in note))
      pos = this.notePos.nextPos(note.width, note.height);
    if (!('xPos' in note)) note.xPos = pos.x;
    if (!('yPos' in note)) note.yPos = pos.y;

    if (!('bgcolor' in note)) note.bgcolor = bgColors[0].toString();
    
    if (!('text' in note)) note.text = '';

    // disable editing of a different note
    this.editOff();
    
    var newDiv = document.createElement('div');
    newDiv.setAttribute('class', 'note');
    newDiv.setAttribute('id', note.id);
    newDiv.setAttribute('onmouseover', 'workspace.notes.' + note.id + '.mouseOver();');
    newDiv.setAttribute('onmouseout', 'workspace.notes.' + note.id + '.mouseOut();');
    newDiv.setAttribute('onmousedown', 'workspace.notes.' + note.id + '.mouseDown(event);');
    newDiv.setAttribute('onmouseup', 'workspace.notes.' + note.id + '.mouseUp();');
    newDiv.setAttribute('onmousemove', 'workspace.notes.' + note.id + '.mouseMove(event);');
    newDiv.setAttribute('ondblclick', 'workspace.notes.' + note.id + '.mouseDblClick();');
    newDiv.setAttribute('title', 'double click to edit');
    // work around a safari bug
    if (isSaf)
      newDiv.style.opacity = '0.99';
    document.body.appendChild(newDiv);

    //document.body.innerHTML += newDiv;
    var elt = get(note.id);
    elt.style.backgroundColor = note.bgcolor;
    elt.style.width = note.width + 'px';
    elt.style.height = note.height + 'px';
    elt.style.left = note.xPos + 'px';
    elt.style.top = note.yPos + 'px';
    elt.style.padding = notePadding + 'px';
    elt.style.position = 'absolute';
    elt.style.border = noteBorder + 'px ' + noteBorderColor + ' solid';

    if (!('zIndex' in note))
    {
      this.reZOrder();
      elt.style.zIndex = this.numNotes + 1;
    }
    else
      elt.style.zIndex = note.zIndex;
    this.numNotes++;
    var nNote = new Note(elt, this, note.text);
    this.notes[nNote.id] = nNote;

    if (isIE)
    {
      var n = nNote;
      newDiv.onmouseover = function() {
        n.mouseOver();
      };
      newDiv.onmouseout = function() {
        n.mouseOut();
      };
      newDiv.onmousedown = function() {
        n.mouseDown(event);
      };
      newDiv.onmouseup = function() {
        n.mouseUp();
      };
      newDiv.onmousemove = function() {
        n.mouseMove(event);
      }
      newDiv.ondblclick = function() {
        n.mouseDblClick();
      };
    }
    this.filter('');
  },
  /**
   * Mouse up action on the workspace.
   */
  mouseUp : function()
  {
    if (this.mouse.selObj)
    {
      this.mouse.selObj.deselect();
      delete this.mouse.selObj;
    }
  },
  /**
   * If we are editing any note, stop editing.
   */
  editOff : function()
  {
    if (this.edit)
    {
      var textbox = get(this.edit.id + 'text');
      
      // check to see if the text changed.  add to the
      // undo stack if it did.
      if (textbox.value != this.edit.text)
      {
        f = {
          title : 'edit note',
          utext : this.edit.text,
          rtext : textbox.value,
          note : this.edit,
          undo : function()
          {
            this.note.setText(this.utext);
          },
          redo : function()
          {
            this.note.setText(this.rtext);
          }
        };
        this.history.add(f);
      }
      
      this.edit.setText(textbox.value);
      this.edit = '';
    }
  },
  /**
   * Resort the notes and place topNoteID in front.
   * @param {string} topNoteID the name of the note to bring to the front.
   */
  reZOrder : function(topNoteID)
  {
    if (this.notes)
    {
      // it's not possible to sort an associative array
      // so we copy it into a regular array first
      var nArray = new Array();
      var i = 0;
      for (nid in this.notes)
      {
        nArray[i] = this.notes[nid];
        i++;
      }
      
      nArray.sort(cmpNotesZ);

      // set zIndex based on order
      var found = 0;
      for (i = 0; i < nArray.length; i++)
      {
        if (nArray[i].id == topNoteID)
        {
          found = 1;
          get(nArray[i].id).style.zIndex = this.numNotes;
        }
        else
          get(nArray[i].id).style.zIndex = i + 1 - found;
      }
    }
  },
  
  /**
   * Set the name of the workspace.  NOTE: this changes where notes get
   * saved.
   * @param {string} n the new name
   */
  setName : function(n)
  {
    this.name = n;
    var elt = get('wsname');
    elt.innerHTML = this.name;
  },
  /**
   * This function acts as an "Expose`" like feature for the notes
   * It sets all of the notes to relative positioning and then grabs
   * the relative location, sets its "top" and "left" properties then
   * resets the positioning to absolute. -sph
   *
   * original patch submitted by Sean Hannan
   *
   * This isn't quite ready for release.
   */
  expose : function() {
    var n, style;
    for (n in this.notes) { //loop through the notes
      var note = this.notes[n];
      var elt = get(note.id);  // get the div
      style = elt.style; //get the note's style
      
      // save old values
      note.lastX = style.left;
      note.lastY = style.top;
      note.lastWidth = style.width;
      note.lastHeight = style.height;
      
      //Set the styles so that the notes nicely tile
      style.position = 'relative';
      style.margin = '5px';
      style.left = '';
      style.top = '';
      style.cssFloat = 'left';
      style.styleFloat = 'left';
      style.display = '';
      style.width = parseInt(exposeSize / 100.0 * parseInt(style.width)) + 'px';
      style.height = parseInt(exposeSize / 100.0 * parseInt(style.height)) + 'px';
      style.fontSize = exposeSize + '%';
      
      //get and set the position of the div
      var pos = findPos(elt);
      style.left = pos.x + 'px';
      style.top = pos.y + 'px';
    }
    //loop through again to make it absolute.
    for (n in this.notes) {
      style = get(this.notes[n].id).style;
      style.position = 'absolute';
      style.cssFloat = 'none';
      style.styleFloat = 'none';
      style.margin = '';
    }
  },
  
  _expose : function() {
    for (var n in this.notes) {  //loop through notes
      var note = this.notes[n];
      var style = get(note.id).style; //get the Div
      
      // restore values
      style.top = note.lastY;
      style.left = note.lastX;
      style.width = note.lastWidth;
      style.height = note.lastHeight;
      style.fontSize = '100%';
    }
  },

  /**
   * Filter the visible notes (kind of like a search).  Notes that match
   * the regular expression are moved to the front while other notes are
   * disabled and become mostly transparent.
   * @param {string} text the regular expression to filter by
   */
  filter : function(text)
  {
    var shouldHide;
    if (text.trim().substring(0, 6) == 'color:')
    {
      var color = text.trim().substring(6);
      shouldHide = function(note)
      {
        return (colorMap[note.bgColor.toString()] == color);
      };
    }
    else
    {
      var reg = new RegExp(text, 'i');
      shouldHide = function(note)
      {
        return reg.test(note.text);
      };
    }

    for (n in this.notes)
    {
      var note = this.notes[n];
      var elt = get(note.id);
      if (shouldHide(note))
      {
        elt.className = 'note';
        if (isSaf)
          elt.style.opacity = '0.99';
        note.enable();
        get('m' + note.id).className = 'note';
      }
      else
      {
        elt.className = 'noteHide';
        elt.style.zIndex = 0;
        if (isSaf)
          elt.style.opacity = '0.2';
        note.disable();
        get('m' + note.id).className = 'noteHide';
      }
    }
    get('textfilter').value = text;
    this.reZOrder();
    this.updateMiniBox();
  },
  /**
   * Update the background color and tool tips of the mini notes.
   */
  updateMiniBox : function()
  {
    var mini = get('mini');
    var vNotes = 0;
    var total = 0;
    
    for (n in this.notes)
    {
      total++;
      var tmp = new Color(get('m' + n).style.backgroundColor);
      if (!(0 == tmp.r && 0 == tmp.g && 0 == tmp.b))
        vNotes++;
    }
    
    // set the width of the mini div
    var diff = parseInt(Math.max(0, total - 9) / 2) * 10;
    if (isIE) diff += 5; // padding + border
    mini.style.width = (diff + miniWidth) + 'px';
    
    if (0 == total)
      mini.title = 'you have no notes';
    else if (vNotes == total)
      mini.title = 'showing all ' + total + ' notes';
    else if (0 == vNotes)
      mini.title = 'hiding all ' + total + ' notes';
    else
      mini.title = 'showing ' + vNotes + ' of ' + total + ' notes (' 
            + parseInt(100 * vNotes / total) + '%)';
  },
  /**
   * Create the "load old notes" note.
   * @param {int} offset how many saves do we want to go back?
   */

  loadlist : function(offset)
  {
    if (!offset)
      offset = 0;
    
    var xmlhttp = getxmlreqobj();
    var self = this;
    xmlhttp.onreadystatechange = function() {
        if (4 == xmlhttp.readyState && 200 == xmlhttp.status)
        {
          var loadTimes = xmlhttp.responseText.split('|');
          self.createNote( {
            'id' : 'load',
            'height' : '130',
            'width' : '270',
            'bgcolor' : '#ffff30'
          } );
          
          var txt = 'If you wish to load a previous version of this workspace, '
                + 'select the time from the list and press load.'
                + '<div style="text-align: center;"><form method="GET" action="load.py" onmousedown="event.cancelBubble=true;">'
                + '<input type="hidden" name="name" value="'
                + escape(self.name) + '" /><select class="loadfrm" name="time">';
          for (var i = 0; i < loadTimes.length && i < 10; i++)
          {
            txt += "<option value='" + loadTimes[i] + "'>" 
                   + (new MyDate(loadTimes[i])) + "</option>";
          }
          
          txt += "</select><input type='submit' value='load' /><br /><span style='font-size: 0.8em;'>";
          
          if (loadTimes.length > 10)
          {
            txt += "&laquo; <a class='fakelink' onclick='workspace.loadlist(" + (offset+10) + ")'>older</a> ";
            if (offset > 0)
              txt += "| ";
          }
          if (offset > 0)
            txt += "<a class='fakelink' onclick='workspace.loadlist(" + (offset-10) + ")'>newer</a> &raquo;";
          
          txt += "<br />all times are US Eastern Time</span></div>";
          
          self.notes['load'].setText(txt);
          self.reZOrder('load');
        }
    };
    this.createNote( {
      'id' : 'load',
      'height' : '130',
      'width' : '270',
      'bgcolor' : '#ffff30'
    } );
    var txt = 'getting load data...';
    this.notes['load'].setText(txt);
    this.reZOrder('load');

    xmlhttp.open('GET', 'getdates.py?name=' + escape(escape(this.name)) + '&offset=' + offset, true);
    xmlhttp.send('');
  },
  /**
   * Checks to see if the notes have changed since the last time we loaded
   * the notes.
   */
  checkUpdated : function()
  {
    var xmlhttp = getxmlreqobj();
    var self = this;
    xmlhttp.onreadystatechange = function() {
        if (4 == xmlhttp.readyState && 200 == xmlhttp.status)
        {
          var loadTime = xmlhttp.responseText.trim();
          if (loadTime > self.loadedTime)
          {
            self.createNote( {
              'id' : 'updated',
              'xPos' : '0',
              'yPos' : '40',
              'bgcolor' : '#ff6060',
              'height' : '100',
              'text' : "This workspace has been changed by someone else while you were working on it.  If you want to see what the workspace looks like now, you can <a href='" 
                    + escape(escape(escape(self.name))) + "' target='_new'>open it in a new window</a>."
            });
          }
          else
          {
            window.setTimeout('workspace.checkUpdated()', 1000*60*10);
          }
        }
    };
    xmlhttp.open('GET', 'getrecent.py?name=' + escape(escape(this.name)), true);
    xmlhttp.send('');
  },
  /**
   * Generate the xml representation of the workspace (used when saving).
   * @type string
   */
  toString : function()
  {
    var ret = "<workspace name='" + escape(this.name) + "'";
    ret += " nextNoteNum='" + this.nextNoteNum + "'";
    ret += " username='" + this.username + "'";
    ret += ">\n";
    for (nid in this.notes)
      ret += this.notes[nid].toXML() + "\n";
    return ret + "</workspace>"
  },
  /**
   * Get the next (or previous) note relative to the top note.
   * @param {int} diff The offset from the top note (positive mean
   * below and negative mean up from the bottom note).
   */
  selectNote : function(diff)
  {
    var max = -1;
    var maxNote;
    var noteArr = [];
    // determine which note is on top
    for (var n in this.notes)
    {
      var cur = parseInt(get(this.notes[n].id).style.zIndex);
      if (cur > max)
      {
        max = cur;
        maxNote = noteArr.length;
      }
      noteArr.push(this.notes[n]);
    }
    noteArr[ (maxNote+diff+noteArr.length) % noteArr.length ].select();
  },
  /**
   * Save the workspace.
   */
  save : function()
  {
    // there have to be changes to the workspace before saving is enabled
    var s = get('saveImg');
    if (s.className == 'controlsDisabled')
      return;
    
    s.src = 'images/saving.gif';						// change the save image
    this.editOff();										// If we are editing any note, stop editing
    
    var xmlhttp = getxmlreqobj();						// initialize XMLHTTP object
    var self = this;
	 
    // Open a http connection to save.aspx
    xmlhttp.open('POST', 'save.aspx', true);			
	
	// Send the xml 
	// Note: when calling 'workspace', it automatically calls the toString method, generating the XML
	xmlhttp.send('' + workspace);						
	
	// Called when readyState changes
	xmlhttp.onreadystatechange = function() {			
	if (4 == xmlhttp.readyState && 200 == xmlhttp.status)	// if readyState is complete and status is ok
	{
	  db("response: " + xmlhttp.responseText.substring(0,2));		
	  //db("response: " + xmlhttp.responseText);		
	  if ("ok" == xmlhttp.responseText.substring(0,2))		// if responseText is 'ok'
	  {
		self.changed = false;
		get('saveImg').className = 'controlsDisabled';
		// The last time that we loaded this workspace (used to check for update collision
		//self.loadedTime = xmlhttp.responseText.substring(4, 23);	
	  }														// if responseText is not 'ok'
	  else 
		alert("Failed to save notes (server error). Please notify me by sending an email to " + adminEmail + " Include what browser you're using and the time the error occurred. Thanks.");
		get('saveImg').src = 'images/save.gif';
	  
	}
	else if (4 == xmlhttp.readyState)						// else readyState is complete but status is not ok
	{
	  db(xmlhttp.status);
	  alert("Failed to save notes (status error). It looks like the save request failed.  Please try again.  If the problem persists, notify me by sending an email to " + adminEmail + ".  Include what browser you're using and the time the error occurred. Thanks.");
	  get('saveImg').src = 'images/save.gif';
	}
  };
	  
	  
  }														
};