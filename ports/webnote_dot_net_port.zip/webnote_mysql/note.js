/**
 * Create a new note object.  You shouldn't need to call this directly, use
 * {@link workspace#createNote} instead.
 * @class A class that acts as a wrapper to the actual html div that is a
 * note.  Rather than operating directly on the html object, use this
 * class instead.
 * TODO: attach these methods directly to the html objects.
 * @param {HtmlElement} note a reference to the actual note or a string that
 * is the id of the note
 * @param {workspace} p a reference to the parent workspace
 * @param {string} text the text of the note
 */
function Note(note, p, text)
{
  // constructor code
  if (typeof note == 'string')
    note = get(note);
  if (!text) text = ''
  // 
  /**
   * TODO: fix references to workspace with this.parent
   * @type workspace
   */
  this.parent = p;
  /**
   * Whether or not is it possible to click on a note and select it
   * @type boolean
   */
  this.selectable = true;
  /**
   * Whether or not we can double click and edit a note
   * @type boolean
   */
  this.editable = true;
  /**
   * The html id of the note
   * @type string
   */
  this.id = note.id;
  /**
   * The height and width of the note
   * @type Point
   */
  this.size = new Point(parseInt(note.style.width), parseInt(note.style.height));

  // create the mini note dom object
  var size = 6;
  var dotElt = document.createElement('div');
  dotElt.setAttribute('id', 'm' + this.id);
  dotElt.setAttribute('onmousedown', 'workspace.notes.' + this.id + '.miniMouseDown(event);');
  get('mini').appendChild(dotElt);

  var dot = get('m' + this.id);
  dot.style.width = size + 'px';
  dot.style.height = (size+1) + 'px';
  dot.style.border = '1px #000 solid';
  dot.style.backgroundColor = note.style.backgroundColor;
  dot.style.margin = '1px 1px 2px 1px';
  dot.style.styleFloat = 'left';
  dot.style.fontSize = '1px';
  dot.style.cssFloat = 'left';

  if (isIE)
  {
    var self = this;
    dotElt.onmousedown = function() {
      self.miniMouseDown(event);
    };
  }
  
  // call methods
  this.setColor(note.style.backgroundColor, true);
  this.setText(text);
  this.updateSize();
}
/**
 * User clicked on a note.
 */
Note.prototype.mouseDown = function(ev)
{
  if (!this.selectable)
    return true;

  // alt + rt click == send to back
  // 2 is rt click in both IE and Mozilla
  if (ev.altKey && 2 == ev.button)
  {
    this.sendToBack();
    return true;
  }

  var lbutton = false;
  if (isIE || isSaf) // IE and Safari's button mapping (1, 2, 4)
    lbutton = 1 == ev.button;
  else // mozilla and w3c's button mapping (0, 1, 2)
    lbutton = 0 == ev.button;

  // only the left button should have an event
  // likewise we can disable actions by using meta or ctrl+alt
  if (!lbutton || ev.metaKey || (ev.ctrlKey && ev.altKey))
    return true;
  
  ev.cancelBubble = true;
  this.parent.mouse.select(this, ev);
  return true;
}
/**
 * User clicked on one of the mini notes at the top of the page.
 */
Note.prototype.miniMouseDown = function(ev)
{
  if (ev.ctrlKey) // bring all notes of the same color to the front
  {
    for (var n in this.parent.notes)
    {
      var note = this.parent.notes[n];
      if (note != this && note.bgColor.toString() == this.bgColor.toString())
        note.select();
    }
  }
  else if (ev.shiftKey)
  {
    workspace.filter('color:' + colorMap[this.bgColor.toString()]);
  }
  this.select();
    
  // bring it back if it's off screen
  var size = this.getCorrectedSize();
  var pos = this.getPosition();
  var elt = get(this.id);
  if (size.x + pos.x < 5)
    elt.style.left = "1px";
  if (size.y + pos.y < 5)
    elt.style.top = "1px";
}
/**
 * User deselected a note (stopped dragging).
 */
Note.prototype.mouseUp = function() { this.parent.mouse.deselect(); }
/**
 * Note keyboard events.
 */
Note.prototype.keyDown = function(ev)
{
  // don't do anything if we're editing the note
  if (this.parent.edit == this)
    return;
  
  // set the color based on number
  idx = parseInt(String.fromCharCode(ev.keyCode)) - 1;
  if (idx >= 0 && idx < bgColors.length)
    this.setColor(bgColors[idx]);
}
/**
 * Moving the mouse while over a note (changes cursor).
 */
Note.prototype.mouseMove = function(ev)
{
  var elt = get(this.id);
  if (!this.selectable)
  {
    elt.style.cursor = 'auto';
    return;
  }
  if (this.parent.mouse.selObj)
    return;
  if (isIE)
  {
    ev.layerX = ev.offsetX + noteBorder;
    ev.layerY = ev.offsetY + noteBorder;
  }
  var top = false;
  var left = false;
  var right = false;
  var bottom = false;
  var size = this.getCorrectedSize();
  
  if (ev.layerX <= noteBorder)
    left = true;
  if (size.x - ev.layerX <= noteBorder)
    right = true;
  if (ev.layerY <= noteBorder)
    top = true;
  if (size.y - ev.layerY <= noteBorder)
    bottom = true;
  if ( (top && left) || (bottom && right) )
    elt.style.cursor = 'nw-resize';
  else if ( (top && right) || (bottom && left) )
    elt.style.cursor = 'ne-resize';
  else if (top || bottom)
    elt.style.cursor = 'n-resize';
  else if (left || right)
    elt.style.cursor = 'e-resize';
  else
    elt.style.cursor = 'move';
  this.parent.mouse.notePosRel['top'] = top;
  this.parent.mouse.notePosRel['bottom'] = bottom;
  this.parent.mouse.notePosRel['left'] = left;
  this.parent.mouse.notePosRel['right'] = right;
}
/**
 * Mouse moves over a note (darken the background color).
 */
Note.prototype.mouseOver = function()
{
  var elt = get(this.id);
  elt.style.background = (new Color(this.bgColor.toString())).hsvadj(0, 0, -0.1);
  this.parent.mouse.noteOver = this;
}
/**
 * Mouse leaves a note (restore original background color).
 */
Note.prototype.mouseOut = function()
{
  var elt = get(this.id);
  elt.style.backgroundColor = this.bgColor.toString();
  delete this.parent.mouse.noteOver;
}

/**
 * Double-click event on a note (try to toggle edit mode).
 */
Note.prototype.mouseDblClick = function()
{
  if (!this.editable)
    return;
  
  if (this.parent.edit == this)
  {
    this.parent.editOff();
    return;
  }
  this.parent.editOff();
  var pSize = this.getCorrectedSize();
  pSize.x -= 2*(noteBorder+notePadding+1);
  pSize.y -= 2*(noteBorder+notePadding+1) + 16;
  var html = "<div style='text-align:right;margin: 0 2 1 0;'>"

  // color swatches here
  var i = 1;
  for (c in bgColors)
  {
    html += "<div style='width: 12px;height:12px;font-size:1px;float:left;background: "
          + bgColors[c] + ";border: 1px #000 solid; margin:0 1px 1px 0;cursor:auto;' "
          + "onmousedown='workspace.notes." + this.id
          + ".setColor(\"" + bgColors[c] + "\");event.cancelBubble=true;' title='press "
          + i + " when not in edit mode change to this color'></div>";
    i++;
  }
  
  html += "<img onclick='workspace.notes." + this.id 
        + ".destroy(true);' src='images/close.gif' alt='close button'"
        + " title='click to destroy note' style='cursor:auto;border:0;height:12px;width:12px;' />"
        + "</div><textarea wrap='virtual' id='"
        + this.id + "text' style='width:" + pSize.x
        + "px;height:" + pSize.y + "px' onmousedown='event.cancelBubble=true;' ondblclick='event.cancelBubble=true;'>"
        + this.text + '</textarea>';
  var elt = get(this.id);
  elt.innerHTML = html;
  elt.title = '';
  get(this.id + 'text').focus();
  this.parent.edit = this;
}

/**
 * Destroy the note (user clicked on the X).
 * @param {boolean} addToHistory should we add information to the undo
 * stack?
 */
Note.prototype.destroy = function(addToHistory)
{
  // if it's being edited, turn it off
  if (this.parent.edit == this)
    this.parent.editOff();
  
  var elt = get(this.id);
  
  // save undo information
  if (addToHistory)
  {
    var pos = this.getPosition();
    var ws = this.parent;
    var f = {
      title : 'delete note',
      noteData : {
          'id' : this.id,
          'xPos' : pos.x,
          'yPos' : pos.y,
          'height' : this.size.y,
          'width' : this.size.x,
          'bgcolor' : this.bgColor.toString(),
          'zIndex' : elt.style.zIndex,
          'text' : this.text
        },
      undo : function()
      {
        ws.createNote(this.noteData);
      },
      redo : function()
      {
        ws.notes[this.noteData.id].destroy(false);
      }
    };
    this.parent.history.add(f);
  }
  
  // now delete the html node
  elt.parentNode.removeChild(elt);
  
  // delete the mini html node
  elt = get('m' + this.id);
  elt.parentNode.removeChild(elt);

  // remove it from the array of notes
  delete this.parent.notes[this.id];
  this.parent.numNotes--;
  
  // resize the mini box and update the stats
  this.parent.updateMiniBox();
  
  // is the garbage collector smart enough to delete the object now?
}
/**
 * Get the coordinates of the upper left corner of the note.
 * @type Point
 */
Note.prototype.getPosition = function()
{
  var ret = new Point(0, 0);
  var elt = get(this.id);
  if (elt)
    ret = new Point(parseInt(elt.style.left), parseInt(elt.style.top));
  return ret;
}
/**
 * Get the size of the note according to the dom object (this varies on
 * browser).
 * @type Point
 */
Note.prototype.getSize = function()
{
  return new Point(this.size.x, this.size.y);
}
/**
 * Get the size of the note including border and padding.
 * @type Point
 */
Note.prototype.getCorrectedSize = function()
{
  var ret = this.getSize();
  if (!isIE)
  {
    ret.x += 2*(noteBorder+notePadding);
    ret.y += 2*(noteBorder+notePadding);
  }
  return ret;
}

/**
 * Set the color of a note.
 * @param {string} hex the color in hex
 * @param {boolean} ignoreHistory should we add it to the history?
 * Different default values makes this inconsistent with {@link #destroy}
 */
Note.prototype.setColor = function(hex, ignoreHistory)
{
  var newColor = new Color(hex);

  if (!ignoreHistory)
  {
    var f = {
      title : 'change color',
      note : this,
      ucolor : this.bgColor,
      rcolor : newColor,
      undo : function()
      {
        this.note.setColor(this.ucolor.toString(), true);
      },
      redo : function()
      {
        this.note.setColor(this.rcolor.toString(), true);
      }
    }
    this.parent.history.add(f);
  }
  
  this.bgColor = newColor;

  var elt = get(this.id);
  if (this.parent.mouse.noteOver && this.parent.mouse.noteOver == this)
    elt.style.background = (new Color(this.bgColor.toString())).hsvadj(0, 0, -0.1);
  else
    elt.style.background = this.bgColor.toString();
  
  get('m' + this.id).style.background = this.bgColor;
}
/**
 * Convert the text of a note to html.  We perform a simple transform of
 * newlines into <br/> and ! into headings.  Other wiki/textile like
 * transforms would happen here.
 * @type string
 */
Note.prototype.getHTML = function() // wikification
{
  var sCopy = this.text.replace(/\n/g,"<br />\n");
  var lines = sCopy.split('\n');
  for (var i = 0; i < lines.length; i++)
  {
    if (lines[i].length > 0)
    {
      // handle headings
      switch(lines[i].charAt(0))
      {
        case '!': // headings
          var c = 0;
          while ('!' == lines[i].charAt(c))
            c++;
          lines[i] = lines[i].substring(c);
          c = Math.min(c, 3); // h3 is the biggest
          c = 4 - c;
          lines[i] = '<h' + c + '>' + lines[i] + '</h' + c + '>';
          break;
        default:
          // lines[i] = lines[i] + '<br />';
      }
    }
  }
  // this is a way to disable text selection, but it's not easy to turn it
  // back on
  //"<div id='pseudo" + this.id 
  // + "' unselectable='on' onmousedown='return ev.metaKey || (event.ctrlKey && event.altKey)'>" 
  return lines.join('');
}
/**
 * Generate the xml representing a note (used when we save notes).
 * @type string
 */
Note.prototype.toXML = function()
{
  var ret = "<note noteid='" + this.id + "'";
  ret += " bgcolor='" + this.bgColor + "'";
  ret += " xposition='" + this.getPosition().x + "'";
  ret += " yposition='" + this.getPosition().y + "'";
  ret += " height='" + this.getSize().y + "'";
  ret += " width='" + this.getSize().x + "'";
  ret += " zindex='" + get(this.id).style.zIndex + "'";
  ret += ">\n" + escape(this.text) + "\n";
  return ret + "</note>"
}
/**
 * Change the text of a note.
 * @param {string} str the text for the note.
 */
Note.prototype.setText = function(str)
{
  // convert characters from 160-255 to html codepoints (this provides
  // Safari compatability
  var chars = new Array();
  var i;
  for (i = 0; i < str.length; i++)
  {
    var c = str.charCodeAt(i);
    if (c >= 160 && c <= 255)
      chars.push("&#" + c + ";");
    else
      chars.push(str.charAt(i));
  }
  str = chars.join('');

  if (str != this.text)
  {
    this.parent.changed = true;
    this.text = str;
  }
  var elt = get(this.id);
  elt.innerHTML = this.getHTML();

  // make images undraggable
  var imgs = elt.getElementsByTagName('img');
  for (i = 0; i < imgs.length; i++)
  {
    if (isIE)
      imgs[i].setAttribute('unselectable', 'on');
    else
      imgs[i].onmousedown = function() { return false; };
  }
  
  elt.title = 'double click to edit';
  get('m' + this.id).title = str;
}
/**
 * We keep track of the size of the note internally; this method updates
 * that value.
 */
Note.prototype.updateSize = function()
{
  var elt = get(this.id);
  this.size.x = parseInt(elt.style.width);
  this.size.y = parseInt(elt.style.height);
}
/**
 * Disable a note (can't be moved or edited).
 */
Note.prototype.disable = function()
{
  this.selectable = this.editable = false;
  var elt = get(this.id);
  elt.title = '';
}
/**
 * Enable a note (can be moved and edited).
 */
Note.prototype.enable = function()
{
  this.selectable = this.editable = true;
  var elt = get(this.id);
  elt.title = 'double click to edit';
}
/**
 * When a note is selected from the mini note toolbar, we bring it to the
 * front and flash the background.
 */
Note.prototype.select = function()
{
  this.parent.reZOrder(this.id);
  var self = this;
  var elt = get(this.id);
  elt.style.backgroundColor = (new Color(this.bgColor.toString())).hsvadj(0, 0, -0.1);
  setTimeout(function() { elt.style.backgroundColor = self.bgColor.toString(); }, 500);
}
/**
 * Send a note to the back of the workspace.
 */
Note.prototype.sendToBack = function()
{
  var elt = get(this.id);
  elt.style.zIndex = 0;
  this.parent.reZOrder();
}

/**
 * Determine which note is above which other note.  Used when re-stacking
 * notes.  Returns -1 if a is below b, +1 if a is above b, and 0 if they
 * have the same z value.
 * @param {Note} a
 * @param {Note} b
 * @type int
 */
function cmpNotesZ(a, b)
{
  var av = parseInt(get(a.id).style.zIndex);
  var bv = parseInt(get(b.id).style.zIndex);
  if (av < bv)
    return -1;
  if (av > bv)
    return 1;
  return 0;
}