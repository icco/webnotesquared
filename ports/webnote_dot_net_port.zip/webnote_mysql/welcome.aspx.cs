using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
//Added
using System.Data.Odbc;         // For database connection to MySQL
using System.Text;              // For 'StringBuilder' class
using System.IO;                // For file read/write

public partial class welcome_aspx
{
    protected string username;

    void Page_Load(Object sender, EventArgs e)
    {
        username = Request.QueryString["user"];
    }

    public string retrieveWorkspaces()
    {
        StringBuilder html = new StringBuilder();

        OdbcConnection conn = new OdbcConnection(Application["connStr"].ToString());

        try
        {
            conn.Open();

            string query = "SELECT wn_workspaces.wsname FROM wn_workspaces, wn_userworkspaces " +
                                "WHERE wn_userworkspaces.username='" + username + "' " +
                                "AND wn_userworkspaces.wsid = wn_workspaces.wsid;";

            OdbcCommand cmd = new OdbcCommand(query, conn);
            OdbcDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                html.Append("<TR><TD><A href='workspace.aspx?user=" + username + "&name=");
                html.Append(reader["wsname"] + "'>" + reader["wsname"].ToString().ToUpper() + "</A></TD></TR>");
            }

        }
        catch (OdbcException ex)
        {
            log(ex.Message);
        }
        finally
        {
            conn.Close();
        }

        return html.ToString();
    }

    /////////////////////
    // Load the workspace
    void btnLoad_Click(object sender, EventArgs e)
    {
        Response.Redirect("workspace.aspx?name=" + txtName.Text + "&user=" + username);
    }

    //////////////////
    // Sign out
    void btnSignOut_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    ///// LOGGING!!
    // This method logs the input variable 'msg' to a file log.txt
    public void log(string msg)
    {
        // Open a file for reading and writing.
        // Second parameter, "true", tells the StreamWriter to append the text if file exist or create file if it doesnt.
        using (StreamWriter sw = new StreamWriter(Server.MapPath("logs\\log.txt"), true))
        {
            // Add some text to the file.
            sw.WriteLine(DateTime.Now + "   " + msg);
        }
    }

}
