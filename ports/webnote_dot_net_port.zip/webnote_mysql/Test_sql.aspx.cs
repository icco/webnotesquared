using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
// Added
//using System.Data.SqlClient;
using System.Data.Odbc;         // For database connection to MySQL

public partial class Test_sql_aspx
{
    void Page_Load(Object sender, EventArgs e)
    {

        Response.Write("testing");

        
        OdbcConnection conn = new OdbcConnection(Application["connStr"].ToString());
        
        try
        {
            conn.Open();

            string query = "SELECT count(username) FROM wn_users WHERE username='joe';";

            //string query = "INSERT INTO wn_users (username) VALUES('phil');";

            OdbcCommand cmd = new OdbcCommand(query, conn);
            OdbcDataReader reader = cmd.ExecuteReader();

            //cmd.ExecuteNonQuery();
          
            reader.Read();

            Response.Write(reader[0]);
            
            

        }
        catch (OdbcException ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            conn.Close();
        }

    }
}