using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
//
using System.Data.Odbc;     // For database connection to MySQL
using System.IO;            // For 'StreamReader' class

public partial class Default_aspx
{
    string username;

    void Page_Load(Object sender, EventArgs e)
    {
        // doesnt work!
        txtUser.Focus();
    }

    //////////////////////////////
    // Load welcome page for user
    void btnLoad_Click(object sender, EventArgs e)
    {
        username = txtUser.Text;

        // Verify that user exists in database.  If not, then add user.
        verifyUserExist();

        // Redirect to the user's welcome page
        Response.Redirect("welcome.aspx?user=" + username);
    }

    ///////////////////////////////
    // Load Sample workspace button
    void btnSample_Click(object sender, EventArgs e)
    {
        Response.Redirect("workspace.aspx?name=sample&user=sample");
    }

    //////////////////////////////////////////////////////////
    // Verifies if workspace exist in database, if not creates it
    public void verifyUserExist()
    {
        OdbcConnection conn = new OdbcConnection(Application["connStr"].ToString());

        try
        {
            conn.Open();
            string query;

            if (!existsInDB())
            {
                query = "INSERT INTO wn_users (username) " +
                                    "VALUES('" + username + "');";

                log("SAVE.ASPX LOGGING:    " + query);

                OdbcCommand cmd = new OdbcCommand(query, conn);
                cmd.ExecuteNonQuery();
            }

        }
        catch (OdbcException ex)
        {
            log(ex.Message);
        }
        finally
        {
            conn.Close();
        }
    }

    // Check if user already exists in database
    // Returns true if exist, false if not
    public Boolean existsInDB()
    {
        OdbcConnection conn = new OdbcConnection(Application["connStr"].ToString());

        try
        {
            conn.Open();

            string query = "SELECT count(username) FROM wn_users WHERE username='" + username + "';";

            OdbcCommand cmd = new OdbcCommand(query, conn);
            OdbcDataReader reader = cmd.ExecuteReader();
            reader.Read();
            
            if (reader[0].ToString() == "1")
                return true;
        }
        catch (OdbcException ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            conn.Close();
        }

        return false;
    }

    ///// LOGGING!!
    // This method logs the input variable 'msg' to a file log.txt
    public void log(string msg)
    {
        // Open a file for reading and writing.
        // Second parameter, "true", tells the StreamWriter to append the text if file exist or create file if it doesnt.
        using (StreamWriter sw = new StreamWriter(Server.MapPath("logs\\log.txt"), true))
        {
            // Add some text to the file.
            sw.WriteLine(DateTime.Now + "   " + msg + "\n");
            sw.Flush();
            sw.Close();
        }
    }

}
