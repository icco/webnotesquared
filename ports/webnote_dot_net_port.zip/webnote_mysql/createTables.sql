CREATE TABLE if not exists wn_workspaces(
    wsid INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    wsname TEXT NOT NULL,
    nextNoteNum INT NOT NULL,
    time TIMESTAMP(14) NOT NULL
) TYPE = InnoDB;

CREATE TABLE if not exists wn_notes (
    nid INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    noteid TEXT NOT NULL,
    text TEXT NOT NULL,
    bgcolor TEXT NOT NULL,
    xposition INT NOT NULL,
    yposition INT NOT NULL,
    height INT NOT NULL,
    width INT NOT NULL,
    zindex INT NOT NULL,
    wsid INT NOT NULL,
    time TIMESTAMP(14) NOT NULL,
    KEY wsid_idx (wsid),
    FOREIGN KEY (wsid) REFERENCES wn_workspaces(wsid)
) TYPE = InnoDB;

CREATE TABLE if not exists wn_users (
  userid int(10) unsigned NOT NULL auto_increment,
  username varchar(45) NOT NULL default '',
  PRIMARY KEY  (`userid`)
) ENGINE=InnoDB 

CREATE TABLE if not exists wn_userworkspaces (
  wsid int(10) unsigned NOT NULL default '0',
  username char(45) NOT NULL default '',
  PRIMARY KEY  (`wsid`,`username`)
) ENGINE=InnoDB