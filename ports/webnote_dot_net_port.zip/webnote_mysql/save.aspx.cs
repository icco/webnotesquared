using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
// Added
using System.IO;            // For 'StreamReader' class
using System.Xml;           // For 'XmlDocument' class
using System.Data.Odbc;     // For database connection to MySQL
using System.Text;          // For 'StringBuilder' class

// If saving does not work, try typing this file into URL directly (ex. http://.../save.aspx) 
// Any compilation errors will be displayed by the .NET framework

public partial class save_aspx
{
    string workspaceName;
    int nextNoteNum;
    int wsid;
    string lasttime;
    string username;

    void Page_Load(Object sender, EventArgs e)
    {
        string xml;

        // Read the input stream 
        using (StreamReader sr = new StreamReader(HttpContext.Current.Request.InputStream, true))
        {
            // Read the input stream to variable 'xml'
            xml = sr.ReadToEnd();
            xml = xml.Replace('\n', ' ');
        }

        if (xml.Length == 0)
        {
            Response.Write("No content to display");
        }
        else
        {
            // Log the input
            log("SAVE.ASPX LOGGING:    " + xml);

            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xml);
            
            // Retrieve the root XmlElement of the document
            // Note: I could also have used "XmlNode root = doc.DocumentElement;", but XmlElement has much more powerful functionality
            XmlElement root = doc.DocumentElement;

            // Retrieve the collection of attributes from the root node
            workspaceName = root.GetAttribute("name");
            nextNoteNum = Convert.ToInt32(root.GetAttribute("nextNoteNum"));
            username = root.GetAttribute("username");

            // Set variables wsid, nextNoteNum, and lasttime
            getInfo();         

            // Update the user workspaces
            updateUserWorkspace();

            XmlNodeList list = root.ChildNodes;

            StringBuilder query = new StringBuilder();
            query.Append("INSERT INTO wn_notes(yposition, bgcolor, text, height, zindex, xposition, noteid, width, time, wsid) VALUES ");

            foreach (XmlElement node in list)
            {
                //log(string.Concat(node.GetAttribute("yposition"), " ", node.GetAttribute("bgcolor"), " ", node.InnerText, " ", node.GetAttribute("height"), " ", node.GetAttribute("zindex"), " ", node.GetAttribute("xposition"), " ", node.GetAttribute("noteid"), " ", node.GetAttribute("width")));
                query.Append("('" + node.GetAttribute("yposition") + "',");
                query.Append("'" + node.GetAttribute("bgcolor") + "',");
                query.Append("'" + node.InnerText + "',");
                query.Append("'" + node.GetAttribute("height") + "',");
                query.Append("'" + node.GetAttribute("zindex") + "',");
                query.Append("'" + node.GetAttribute("xposition") + "',");
                query.Append("'" + node.GetAttribute("noteid") + "',");
                query.Append("'" + node.GetAttribute("width") + "',");
                query.Append("'" + lasttime + "','" + wsid + "'), ");
            }
            
            // Remove the last comma (,) from the query
            query.Remove(query.Length - 2, 2);

            // Log again
            log("SAVE.ASPX LOGGING:    " + query.ToString());
            
            // EXECUTE THE QUERY    
            OdbcConnection conn = new OdbcConnection(Application["connStr"].ToString());

            try
            {
                conn.Open();

                OdbcCommand cmd = new OdbcCommand(query.ToString(), conn);
                cmd.ExecuteNonQuery();

            }
            catch (OdbcException ex)
            {
                log(ex.Message);
            }
            finally
            {
                conn.Close();
            }

        }

        // Send xmlhttp.responseText
        Response.Write("ok ");

    }

    // Sets the variables wsid, nextNoteNumber, and lasttime
    public void getInfo()
    {
        OdbcConnection conn = new OdbcConnection(Application["connStr"].ToString());

        try
        {
            conn.Open();

            // Retrieve the wsid, nextNoteNum, time of the current workspace
            string query = "SELECT wsid, nextNoteNum, DATE_FORMAT(time, '%Y-%m-%d %H:%i:%s')" +
                            " FROM wn_workspaces WHERE wsname='" + workspaceName + "'";
            
            //log("Workspace.aspx Logging:    " + query);

            OdbcCommand cmd = new OdbcCommand(query, conn);
            OdbcDataReader reader = cmd.ExecuteReader();

            reader.Read();
            wsid = Convert.ToInt32(reader[0].ToString());
            nextNoteNum = Convert.ToInt32(reader[1].ToString());
            lasttime = reader[2].ToString();
        }
        catch (OdbcException ex)
        {
             log(ex.Message);
        }
        finally
        {
             conn.Close();
        }
    }


     public void updateUserWorkspace()
     {
         OdbcConnection conn = new OdbcConnection(Application["connStr"].ToString());

         try
         {
             conn.Open();
             
             // Check to see if workspace already exist, if so, do nothing
             string query = "SELECT count(wsid) FROM wn_userworkspaces WHERE wsid='" + wsid + "' AND username='" + username + "'";

             OdbcCommand cmd = new OdbcCommand(query, conn);
             OdbcDataReader reader = cmd.ExecuteReader();
             reader.Read();

             // If user workspace does not exist, then insert it
             if (!reader[0].ToString().Equals("1"))
             {
                 // Insert the user name and current workspace id
                 query = "INSERT INTO wn_userworkspaces(wsid, username) " +
                                                      "VALUES('" + wsid + "', '" + username + "');";

                 log("SAVE.ASPX LOGGING:    " + query);

                 cmd = new OdbcCommand(query, conn);
                 cmd.ExecuteNonQuery();
             }

         }
         catch (OdbcException ex)
         {
             log(ex.Message);
         }
         finally
         {
             conn.Close();
         }
     }

    // Check if workspace already exists in database
    // Returns true if exist, false if not
    public Boolean existsInDB()
    {
        OdbcConnection conn = new OdbcConnection(Application["connStr"].ToString());

        try
        {
            conn.Open();

            string query = "SELECT count(wsname) FROM wn_workspaces WHERE wsname='" + workspaceName + "';";

            OdbcCommand cmd = new OdbcCommand(query, conn);
            OdbcDataReader reader = cmd.ExecuteReader();
            reader.Read();
            //Response.Write(reader[0]);
            if (reader[0].ToString() == "1")
                return true;
        }
        catch (OdbcException ex)
        {
            log(ex.Message);
        }
        finally
        {
            conn.Close();
        }

        return false;
    }

    ///// LOGGING!!
    // This method logs the input variable 'msg' to a file log.txt
    public void log (string msg)
    {
        // Open a file for reading and writing.
        // Second parameter, "true", tells the StreamWriter to append the text if file exist or create file if it doesnt.
        using (StreamWriter sw = new StreamWriter(Server.MapPath("logs\\log.txt"), true))
        {
            // Add some text to the file.
            sw.WriteLine(DateTime.Now + "   " + msg);
            sw.Flush();
            sw.Close();
        }
    }

}